<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="marathon.css?v=<?php echo time(); ?>">
  <link rel="stylesheet" href="marathonmedia.css?v=<?php echo time(); ?>">
  <script src="marathon.js?v=<?php echo time(); ?>"></script>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
  <link href="https://fonts.cdnfonts.com/css/gotham" rel="stylesheet">
  <link rel="icon" type="image/x-icon" href="https://dostyq.online/_nuxt/b24017d0fc470abbf8fe439ea6ba05a7.svg">
  <title>Марафон</title>
</head>
<body>
  <div class="temp">
    <div class="pages">
      <img src="./ImagesZhan/loreg.png" alt="logo1" id="logreg1">
      <a href="LogReg.php" id="y6">Войти</a>
      <p id="ggg"></p>
      <?php
                $isVowel = 'undefined';
                $myname = 'undefined';
                $connection = new mysqli("localhost", "root", "", "logreg");
                  if($connection->connect_error) {
                      die("Connection failed: " . $connection->connect_error);
                  }
          
                  $sql = "SELECT * FROM `vo`;";             
                  $result = $connection->query($sql);     
                  if ($result->num_rows > 0) 
                  {
                      while($row = $result->fetch_assoc())
                      {
                          $isVowel = $row["ItIs"];
                      }
                  } 
                  else {
                      echo "0 results";
                  }

                  $conn = new mysqli("localhost", "root", "", "logreg");
                  if($conn->connect_error) {
                      die("Connection failed: " . $con->connect_error);
                  }
          
                  $sql2 = "SELECT * FROM `logreg`;";   
                  $result = $conn->query($sql2);     
                  if ($result->num_rows > 0) 
                  {
                      while($row = $result->fetch_assoc())
                      {
                          $myname = $row["Namego"];
                      }
                  } 
                  else {
                      echo "0 results";
                  }
                  $conn->close();

                  if($isVowel == 1) {
                    echo "<script>document.getElementById('y6').textContent  = '$myname';</script>";
                  }else {
                    echo "<script>document.getElementById('y6').textContent  = 'Войти';</script>";
                  }

              $connection->close();
              ?>
    </div> 
    <div class="pages">
      <img src="./ImagesZhan/video.png" alt="logo2" id="video1">
      <a href="videocourses.php">Видеокурсы</a> 
    </div>
    <div class="pages">
      <img src="./ImagesZhan/Марафоны.png" alt="logo3" id="marafon">
    <a href="marathon.php">Марафоны</a>
    </div> 
    <div class="pages">
      <img src="./ImagesZhan/prof.png" alt="logo4" id="prof">
    <a href="Prof_Page.php">П-ориент</a> 
    </div>
    <div class="pages">
      <img src="./ImagesZhan/kontact.png" alt="logo4" id="kontact">
    <a href="contacts.php">Контакты</a> 
    </div>
  </div>
<div class="main-vverh">
  <div class="videokursy-main-text">
    Марафоны
    </div>
    <div class="videokursy-opisanie">
      <p>Выбирай и учи только нужные для тебя темы</p>
    </div>
    <div class="language">
    <div class="numofcourses">
      <p>16 курса</p>
    </div>
</div>




 <div class="predmet-grid">

  <div class="karta">
    <div>
      <img class="course-image" src="marathonphotos/tarikh.jpg" alt="">
    </div>
    <div class="center-niz-karty">
      <div class="predmet-text-top">Қазақстан тарихы</div>
      <div class="predmet-text">Қазақстан тарихы. Толық курс</div>
      <div class="dostupen">
        <p class="dostupen-text">Доступен до: 31.05.2022</p>
        <p class="dostupen-text">Осталось мест: 4000</p>
      </div>
      <div class="niz-karty">
        <div class="niz-karty-left">
          <p class="niz-karty-left-yazyk">Язык</p>
          <p class="niz-niz-karty">Русский</p>
        </div>
        <div>
          <p class="niz-karty-left-yazyk">Цена</p>
          <p class="niz-niz-karty">БЕСПЛАТНО</p>
        </div>
      </div>
    </div>
  </div>

  <div class="karta">
    <div>
      <img class="course-image" src="marathonphotos/physmath.jpg" alt="">
    </div>
    <div class="center-niz-karty">
      <div class="predmet-text-top">Физика</div>
      <div class="predmet-text">COMBO ФИЗ+МАТ. 1-поток. Рус</div>
      <div class="dostupen">
        <p class="dostupen-text">Доступен до: 01.03.2022</p>
        <p class="dostupen-text">Осталось мест: 900</p>
      </div>
      <div class="niz-karty">
        <div class="niz-karty-left">
          <p class="niz-karty-left-yazyk">Язык</p>
          <p class="niz-niz-karty">Русский</p>
        </div>
        <div>
          <p class="niz-karty-left-yazyk">Цена</p>
          <p class="niz-niz-karty">БЕСПЛАТНО</p>
        </div>
      </div>
    </div>
  </div>

  <div class="karta">
    <div>
      <img class="course-image" src="marathonphotos/biogeo.jpg" alt="">
    </div>
    <div class="center-niz-karty">
      <div class="predmet-text-top">Биология</div>
      <div class="predmet-text">COMBO БИО+ГЕО. 1-поток. Русс</div>
      <div class="dostupen">
        <p class="dostupen-text">Доступен до: 31.05.2022</p>
        <p class="dostupen-text">Осталось мест: 4000</p>
      </div>
      <div class="niz-karty">
        <div class="niz-karty-left">
          <p class="niz-karty-left-yazyk">Язык</p>
          <p class="niz-niz-karty">Русский</p>
        </div>
        <div>
          <p class="niz-karty-left-yazyk">Цена</p>
          <p class="niz-niz-karty">БЕСПЛАТНО</p>
        </div>
      </div>
    </div>
  </div>

  <div class="karta">
    <div>
      <img class="course-image" src="marathonphotos/mathgeo.jpg" alt="">
    </div>
    <div class="center-niz-karty">
      <div class="predmet-text-top">Математика</div>
      <div class="predmet-text">COMBO МАТ+ГЕО. 1-поток. Рус</div>
      <div class="dostupen">
        <p class="dostupen-text">Доступен до: 31.05.2022</p>
        <p class="dostupen-text">Осталось мест: 4000</p>
      </div>
      <div class="niz-karty">
        <div class="niz-karty-left">
          <p class="niz-karty-left-yazyk">Язык</p>
          <p class="niz-niz-karty">Русский</p>
        </div>
        <div>
          <p class="niz-karty-left-yazyk">Цена</p>
          <p class="niz-niz-karty">БЕСПЛАТНО</p>
        </div>
      </div>
    </div>
  </div>

  <div class="karta">
    <div>
      <img class="course-image" src="marathonphotos/geoeng.jpg" alt="">
    </div>
    <div class="center-niz-karty">
      <div class="predmet-text-top">География</div>
      <div class="predmet-text">COMBO ГЕО+ENG язык. 1-поток. Рус</div>
      <div class="dostupen">
        <p class="dostupen-text">Доступен до: 31.05.2022</p>
        <p class="dostupen-text">Осталось мест: 4000</p>
      </div>
      <div class="niz-karty">
        <div class="niz-karty-left">
          <p class="niz-karty-left-yazyk">Язык</p>
          <p class="niz-niz-karty">Русский</p>
        </div>
        <div>
          <p class="niz-karty-left-yazyk">Цена</p>
          <p class="niz-niz-karty">БЕСПЛАТНО</p>
        </div>
      </div>
    </div>
  </div>

  <div class="karta">
    <div>
      <img class="course-image" src="marathonphotos/vistchop.jpg" alt="">
    </div>
    <div class="center-niz-karty">
      <div class="predmet-text-top">Всемирная история</div>
      <div class="predmet-text">COMBO В.ИСТ + ЧОП. 1-поток. Рус</div>
      <div class="dostupen">
        <p class="dostupen-text">Доступен до: 31.05.2022</p>
        <p class="dostupen-text">Осталось мест: 4000</p>
      </div>
      <div class="niz-karty">
        <div class="niz-karty-left">
          <p class="niz-karty-left-yazyk">Язык</p>
          <p class="niz-niz-karty">Русский</p>
        </div>
        <div>
          <p class="niz-karty-left-yazyk">Цена</p>
          <p class="niz-niz-karty">БЕСПЛАТНО</p>
        </div>
      </div>
    </div>
  </div>

  <div class="karta">
    <div>
      <img class="course-image" src="marathonphotos/visteng.jpg" alt="">
    </div>
    <div class="center-niz-karty">
      <div class="predmet-text-top">Всемирная история</div>
      <div class="predmet-text">COMBO В.ИСТ + ENG. 1-поток. Рус</div>
      <div class="dostupen">
        <p class="dostupen-text">Доступен до: 31.05.2022</p>
        <p class="dostupen-text">Осталось мест: 4000</p>
      </div>
      <div class="niz-karty">
        <div class="niz-karty-left">
          <p class="niz-karty-left-yazyk">Язык</p>
          <p class="niz-niz-karty">Русский</p>
        </div>
        <div>
          <p class="niz-karty-left-yazyk">Цена</p>
          <p class="niz-niz-karty">БЕСПЛАТНО</p>
        </div>
      </div>
    </div>
  </div>

  <div class="karta">
    <div>
      <img class="course-image" src="marathonphotos/khimbio.jpg" alt="">
    </div>
    <div class="center-niz-karty">
      <div class="predmet-text-top">Химия</div>
      <div class="predmet-text">COMBO ХИМ+БИО. 1-поток. Рус</div>
      <div class="dostupen">
        <p class="dostupen-text">Доступен до: 31.05.2022</p>
        <p class="dostupen-text">Осталось мест: 4000</p>
      </div>
      <div class="niz-karty">
        <div class="niz-karty-left">
          <p class="niz-karty-left-yazyk">Язык</p>
          <p class="niz-niz-karty">Русский</p>
        </div>
        <div>
          <p class="niz-karty-left-yazyk">Цена</p>
          <p class="niz-niz-karty">БЕСПЛАТНО</p>
        </div>
      </div>
    </div>
  </div>

  <div class="karta">
    <div>
      <img class="course-image" src="marathonphotos/dzhtakk.png" alt="">
    </div>
    <div class="center-niz-karty">
      <div class="predmet-text-top">Дүниежүзі тарихы</div>
      <div class="predmet-text">COMBO ДЖТ+ҚҰҚЫҚ НЕГІЗДЕРІ. 1-поток. Қаз</div>
      <div class="dostupen">
        <p class="dostupen-text">Доступен до: 31.05.2022</p>
        <p class="dostupen-text">Осталось мест: 4000</p>
      </div>
      <div class="niz-karty">
        <div class="niz-karty-left">
          <p class="niz-karty-left-yazyk">Язык</p>
          <p class="niz-niz-karty">Қазақша</p>
        </div>
        <div>
          <p class="niz-karty-left-yazyk">Цена</p>
          <p class="niz-niz-karty">БЕСПЛАТНО</p>
        </div>
      </div>
    </div>
  </div>

  <div class="karta">
    <div>
      <img class="course-image" src="marathonphotos/geoengkaz.png" alt="">
    </div>
    <div class="center-niz-karty">
      <div class="predmet-text-top">География</div>
      <div class="predmet-text">COMBO ГЕО+ENG. 1-поток. Қаз</div>
      <div class="dostupen">
        <p class="dostupen-text">Доступен до: 31.05.2022</p>
        <p class="dostupen-text">Осталось мест: 4000</p>
      </div>
      <div class="niz-karty">
        <div class="niz-karty-left">
          <p class="niz-karty-left-yazyk">Язык</p>
          <p class="niz-niz-karty">Қазақша</p>
        </div>
        <div>
          <p class="niz-karty-left-yazyk">Цена</p>
          <p class="niz-niz-karty">БЕСПЛАТНО</p>
        </div>
      </div>
    </div>
  </div>

  <div class="karta">
    <div>
      <img class="course-image" src="marathonphotos/biogeokaz.png" alt="">
    </div>
    <div class="center-niz-karty">
      <div class="predmet-text-top">Биология</div>
      <div class="predmet-text">COMBO БИО+ГЕО. 1-поток. Қаз</div>
      <div class="dostupen">
        <p class="dostupen-text">Доступен до: 31.05.2022</p>
        <p class="dostupen-text">Осталось мест: 4000</p>
      </div>
      <div class="niz-karty">
        <div class="niz-karty-left">
          <p class="niz-karty-left-yazyk">Язык</p>
          <p class="niz-niz-karty">Қазақша</p>
        </div>
        <div>
          <p class="niz-karty-left-yazyk">Цена</p>
          <p class="niz-niz-karty">БЕСПЛАТНО</p>
        </div>
      </div>
    </div>
  </div>

  <div class="karta">
    <div>
      <img class="course-image" src="marathonphotos/dzhteng.png" alt="">
    </div>
    <div class="center-niz-karty">
      <div class="predmet-text-top">Дүниежүзі тарихы</div>
      <div class="predmet-text">COMBO ДЖТ+ENG. 1-поток. Қаз</div>
      <div class="dostupen">
        <p class="dostupen-text">Доступен до: 31.05.2022</p>
        <p class="dostupen-text">Осталось мест: 4000</p>
      </div>
      <div class="niz-karty">
        <div class="niz-karty-left">
          <p class="niz-karty-left-yazyk">Язык</p>
          <p class="niz-niz-karty">Қазақша</p>
        </div>
        <div>
          <p class="niz-karty-left-yazyk">Цена</p>
          <p class="niz-niz-karty">БЕСПЛАТНО</p>
        </div>
      </div>
    </div>
  </div>

  <div class="karta">
    <div>
      <img class="course-image" src="marathonphotos/matgeokaz.png" alt="">
    </div>
    <div class="center-niz-karty">
      <div class="predmet-text-top">Математика</div>
      <div class="predmet-text">COMBO МАТ+ГЕО. 1-поток. Қаз</div>
      <div class="dostupen">
        <p class="dostupen-text">Доступен до: 31.05.2022</p>
        <p class="dostupen-text">Осталось мест: 4000</p>
      </div>
      <div class="niz-karty">
        <div class="niz-karty-left">
          <p class="niz-karty-left-yazyk">Язык</p>
          <p class="niz-niz-karty">Қазақша</p>
        </div>
        <div>
          <p class="niz-karty-left-yazyk">Цена</p>
          <p class="niz-niz-karty">БЕСПЛАТНО</p>
        </div>
      </div>
    </div>
  </div>

  <div class="karta">
    <div>
      <img class="course-image" src="marathonphotos/khimbiokaz.png" alt="">
    </div>
    <div class="center-niz-karty">
      <div class="predmet-text-top">Химия</div>
      <div class="predmet-text">COMBO ХИМ+БИО. 1-поток. Қаз</div>
      <div class="dostupen">
        <p class="dostupen-text">Доступен до: 31.05.2022</p>
        <p class="dostupen-text">Осталось мест: 4000</p>
      </div>
      <div class="niz-karty">
        <div class="niz-karty-left">
          <p class="niz-karty-left-yazyk">Язык</p>
          <p class="niz-niz-karty">Қазақша</p>
        </div>
        <div>
          <p class="niz-karty-left-yazyk">Цена</p>
          <p class="niz-niz-karty">БЕСПЛАТНО</p>
        </div>
      </div>
    </div>
  </div>

  <div class="karta">
    <div>
      <img class="course-image" src="marathonphotos/physmathkaz.png" alt="">
    </div>
    <div class="center-niz-karty">
      <div class="predmet-text-top">Физика</div>
      <div class="predmet-text">COMBO ФИЗ+МАТ. 1-поток. Қаз</div>
      <div class="dostupen">
        <p class="dostupen-text">Доступен до: 31.05.2022</p>
        <p class="dostupen-text">Осталось мест: 4000</p>
      </div>
      <div class="niz-karty">
        <div class="niz-karty-left">
          <p class="niz-karty-left-yazyk">Язык</p>
          <p class="niz-niz-karty">Қазақша</p>
        </div>
        <div>
          <p class="niz-karty-left-yazyk">Цена</p>
          <p class="niz-niz-karty">БЕСПЛАТНО</p>
        </div>
      </div>
    </div>
  </div>

  <div class="karta">
    <div>
      <img class="course-image" src="marathonphotos/ktiliadeb.png" alt="">
    </div>
    <div class="center-niz-karty">
      <div class="predmet-text-top">Қазақ тілі</div>
      <div class="predmet-text">COMBO Қ.ТІЛІ+ӘДЕБИЕТ. 1-поток</div>
      <div class="dostupen">
        <p class="dostupen-text">Доступен до: 31.05.2022</p>
        <p class="dostupen-text">Осталось мест: 4000</p>
      </div>
      <div class="niz-karty">
        <div class="niz-karty-left">
          <p class="niz-karty-left-yazyk">Язык</p>
          <p class="niz-niz-karty">Қазақша</p>
        </div>
        <div>
          <p class="niz-karty-left-yazyk">Цена</p>
          <p class="niz-niz-karty">БЕСПЛАТНО</p>
        </div>
      </div>
    </div>
  </div>

</div>

<div class="header">
  <div class="tochki">
    <img class="tochki-image" src="marathonphotos/tochki.svg" alt="" onclick="myFunction()">
  </div>
  <div class="dostyk-icon">
    <img class="dostyqsvg" src="icons/dostyq.svg" alt="">
  </div>
  <div class="dostyq-online">
    <a href="Main.php" class="dostyq-header">dostyq.online</a>
  </div>   
</div> 

<main>

  <div class="oqulyqtar">
    <p>Наши книги</p>
  </div>
  
  <div class="animated-slider">
    <div class="slider">
      <div class="slides">
        <input type="radio" name="radio-btn" id="radio1">
        <input type="radio" name="radio-btn" id="radio2">
        <input type="radio" name="radio-btn" id="radio3">
        <input type="radio" name="radio-btn" id="radio4">
    
        <div class="slide first">
          <img src="https://static.tildacdn.com/tild3861-3231-4561-a130-353363363631/photo.png" alt="">
        </div>
        <div class="slide">
          <img src="https://static.tildacdn.com/tild3861-6665-4337-a438-346366386236/_.png" alt="">
        </div>
        <div class="slide">
          <img src="https://static.tildacdn.com/tild3033-3964-4038-a133-636562376234/photo.png" alt="">
        </div>
        <div class="slide">
          <img src="https://static.tildacdn.com/tild3539-3737-4435-b565-393664333965/photo.png" alt="">
        </div>
    
        <div class="navigation-auto">
          <div class="auto-btn-1"></div>
          <div class="auto-btn-2"></div>
          <div class="auto-btn-3"></div>
          <div class="auto-btn-4"></div>
        </div>
      </div>
    
        <div class="navigation-mannual">
          <label for="radio1" class="mannual-btn"></label>
          <label for="radio2" class="mannual-btn"></label>
          <label for="radio3" class="mannual-btn"></label>
          <label for="radio4" class="mannual-btn"></label>
        </div>
    </div>
    </div>

    <div class="chart">
      <div class="x-box"></div>
      <div class="x-box-cont">
        <h1>Біздің оқушылар қандай мектептерді таңдайды</h1>
        <br>
        <strong style="color: #ff264a">NIS 35%</strong>
        <strong style="color: #feec1e">BIL 35%</strong>
        <strong style="color: #12cbc4">NURORDA 30%</strong>
      </div>
      </div>



<div class="footer">
  <div class="left-footer">
    <div class="dostyq-image-container">
      <img class="dostyq-image-container-icon" src="icons/dostyq.svg" alt="">
    </div>

    <div class="left-footer-right">
      <p class="dostyq">dostyq.online</p>
      <p class="svyazh">Свяжитесь с нами</p>
      <p class="dostyq-nomer">+7 707 422 19 19</p>
    </div>
  </div>
  <div class="right-footer">
    <div>
      <p class="weinmedia">Мы в социальных сетях</p>
    </div>
    <div class="socset">
      <img src="icons/whatsapp.svg" alt="">
      <img src="icons/youtube.svg" alt="">
      <img src="icons/instagram.svg" alt="">
    </div>
  </div>
</div>



<div class="after-footer">
  <div>
    <p class="after-footer-text">© 2022 Dostyq Bilim. Все права защищены.</p>
  </div>
  <div class="right-after-footer">
    <div>
      <p class="after-footer-text">Политика конфиденциальности</p>
    </div>
    <div>
      <p class="after-footer-text">
        Договор оферты
      </p>
    </div>
  </div>
</div>

</main>

</body>
</html>