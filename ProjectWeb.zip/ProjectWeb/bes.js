function ubt() {
    const arr = [98,100,101,139];
    let x = document.getElementsByClassName("menu-text-title");
    let y = document.getElementsByClassName("about-text");
    document.getElementById("i1").src = './images/bekarys.jpg';
    x[0].innerHTML = "Байболат Бекарыс";
    y[0].innerHTML = `Тобы: <code>NIS</code> <br> ҰБТ балы: 100 + 39`;
    x[1].innerHTML = "Фотомодель";
    document.getElementById("i2").src = './images/mukha.jpg';
    x[2].innerHTML = "Рабаев Мұқтар";
    y[1].innerHTML = `Тобы: <code>КТЛ</code> <br> ҰБТ балы: 101`;
    x[3].innerHTML = "КТЛщик";
    document.getElementById("i3").src = './images/alimingoi.jpg';
    x[4].innerHTML = "Мақсотов Әли";
    y[2].innerHTML = `Тобы: <code>MFK-1</code> <br> ҰБТ балы: 100`;
    x[5].innerHTML = "Жақсы бала";
    document.getElementById("i4").src = './images/photo_2022-12-19_22-56-18.jpg';
    x[6].innerHTML = "Темірқанат Жандарбек";
    y[3].innerHTML = `Тобы: <code>MFK-2</code> <br> ҰБТ балы: 99`;
    x[7].innerHTML = "Әзілқой";
}

function tobi() {
        const arr = [98,100,101,139];
    let x = document.getElementsByClassName("menu-text-title");
    let y = document.getElementsByClassName("about-text");
    document.getElementById("i3").src = './images/bekarys.jpg';
    x[4].innerHTML = "Байболат Бекарыс";
    y[2].innerHTML = `Тобы: <code>NIS</code> <br> ҰБТ балы: 100 + 39`;
    x[5].innerHTML = "Фотомодель";
    document.getElementById("i4").src = './images/mukha.jpg';
    x[6].innerHTML = "Рабаев Мұқтар";
    y[3].innerHTML = `Тобы: <code>КТЛ</code> <br> ҰБТ балы: 101`;
    x[7].innerHTML = "КТЛщик";
    document.getElementById("i1").src = './images/alimingoi.jpg';
    x[0].innerHTML = "Мақсотов Әли";
    y[0].innerHTML = `Тобы: <code>MFK-1</code> <br> ҰБТ балы: 100`;
    x[1].innerHTML = "Жақсы бала";
    document.getElementById("i2").src = './images/photo_2022-12-19_22-56-18.jpg';
    x[2].innerHTML = "Темірқанат Жандарбек";
    y[1].innerHTML = `Тобы: <code>MFK-2</code> <br> ҰБТ балы: 99`;
    x[3].innerHTML = "Әзілқой";
}

function boi() {
    const arr = [98,100,101,139];
    let x = document.getElementsByClassName("menu-text-title");
    let y = document.getElementsByClassName("about-text");
    document.getElementById("i2").src = './images/bekarys.jpg';
    x[2].innerHTML = "Байболат Бекарыс";
    y[1].innerHTML = `Тобы: <code>NIS</code> <br> ҰБТ балы: 100 + 39`;
    x[3].innerHTML = "Фотомодель";
    document.getElementById("i3").src = './images/mukha.jpg';
    x[4].innerHTML = "Рабаев Мұқтар";
    y[2].innerHTML = `Тобы: <code>КТЛ</code> <br> ҰБТ балы: 101`;
    x[5].innerHTML = "КТЛщик";
    document.getElementById("i1").src = './images/alimingoi.jpg';
    x[0].innerHTML = "Мақсотов Әли";
    y[0].innerHTML = `Тобы: <code>MFK-1</code> <br> ҰБТ балы: 100`;
    x[1].innerHTML = "Жақсы бала";
    document.getElementById("i4").src = './images/photo_2022-12-19_22-56-18.jpg';
    x[6].innerHTML = "Темірқанат Жандарбек";
    y[3].innerHTML = `Тобы: <code>MFK-2</code> <br> ҰБТ балы: 99`;
    x[7].innerHTML = "Әзілқой";
}