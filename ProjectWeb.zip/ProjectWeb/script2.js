let x = document.getElementsByClassName("close");
window.onload = function() {
x[0].addEventListener('click', function() {
    location.replace("Main.php");
});
};