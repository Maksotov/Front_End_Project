<!Doctype html>
<head> 
    <meta charset="UTF-8">
    <meta name = "viewport" content="width = device - width , initial-scale=1.0">
    <link rel="stylesheet" href="Prof_Page.css?v=<?php echo time(); ?>">
    <link rel="stylesheet" href="Prof-Page(Media).css?v=<?php echo time(); ?>">
    <link rel="icon" type="image/x-icon" href="https://dostyq.online/_nuxt/b24017d0fc470abbf8fe439ea6ba05a7.svg">
    <title>Профориентация</title>
</head>

<body>
    <div class="header">
        <div class="logo_button_online">
        <button class="ush_tochka" onclick="myFunction()">
            <img src = "https://dostyq.online/_nuxt/dce8120e860949ae90f5d4398743e394.svg">
        </button>
        <div class="dostyq_logo">
            <a  href = "Main.php">
                <img src="https://dostyq.online/_nuxt/b24017d0fc470abbf8fe439ea6ba05a7.svg">
                <div class="dostyq_online">
                <b>dostyq.online</b>
                </div>
            </a> 
        </div>
        </div>
    </div>
    <div class="temp">
      <div class="pages">
        <img src="./ImagesZhan/loreg.png" alt="logo1" id="logreg1">
        <a href="LogReg.php" id="y6">Войти</a>
        <p id="ggg"></p>
        <?php
        $isVowel = 'undefined';
        $myname = 'undefined';
        $connection = new mysqli("localhost", "root", "", "logreg");
          if($connection->connect_error) {
              die("Connection failed: " . $connection->connect_error);
          }
  
          $sql = "SELECT * FROM `vo`;";             
          $result = $connection->query($sql);     
          if ($result->num_rows > 0) 
          {
              while($row = $result->fetch_assoc())
              {
                  $isVowel = $row["ItIs"];
              }
          } 
          else {
              echo "0 results";
          }

          $conn = new mysqli("localhost", "root", "", "logreg");
          if($conn->connect_error) {
              die("Connection failed: " . $con->connect_error);
          }
  
          $sql2 = "SELECT * FROM `logreg`;";   
          $result = $conn->query($sql2);     
          if ($result->num_rows > 0) 
          {
              while($row = $result->fetch_assoc())
              {
                  $myname = $row["Namego"];
              }
          } 
          else {
              echo "0 results";
          }
          $conn->close();

          if($isVowel == 1) {
            echo "<script>document.getElementById('y6').textContent  = '$myname';</script>";
          }else {
            echo "<script>document.getElementById('y6').textContent  = 'Войти';</script>";
          }

      $connection->close();
      ?>
      </div> 
      <div class="pages">
        <img src="./ImagesZhan/video.png" alt="logo2" id="video1">
        <a href="videocourses.php">Видеокурсы</a> 
      </div>
      <div class="pages">
        <img src="./ImagesZhan/Марафоны.png" alt="logo3" id="marafon">
      <a href="marathon.php">Марафоны</a>
      </div> 
      <div class="pages">
        <img src="./ImagesZhan/prof.png" alt="logo4" id="prof">
      <a href="Prof_Page.php">Профориентация</a> 
      </div>
      <div class="pages">
        <img src="./ImagesZhan/kontact.png" alt="logo4" id="kontact">
      <a href="contacts.php">Контакты</a> 
      </div>
    </div>
    <div class="Div1_Polnye">
    <div class="Div1">
    <div class="toggle">
        <img src="./ImagesZhan/Toggle.svg">
        <h3>20 минут</h3>
    </div>
    <div class="text1">
        <h1>Тегін кәсіптік<br>бағдар беру тесті</h1>
        <h3>Мамандық пен таңдау пәнін таңдауға көмектесеміз</h3>
    </div>
    <div class="Ustingi_button">
        <a href="https://proforientator.ru/tests/" style="text-decoration: none; color: white;" target="_blank"><button class="Synak">Сынақты бастау</button></a>
        <button class="Kobirek" onclick="ggg()">Көбірек</button>
    </div>
    </div>
    <div id="myModal" class="modal">
        <div class="modal-content">
          <span class="close" onclick="hhh()">&times;</span>
          <p>Мазмұны: <br>
            1-қадам. Қай жерде жұмыс істеу керек <br>
            2-қадам. Элементтер (материалдар) <br>
            Қадам 3. Объектілермен әрекеттер <br>
            4-қадам. Орындар тізімін реттеу <br>
            5-қадам. Мен не істей аламын <br>
            Қадам 6. Өнімді және репродуктивті тәсіл <br>
            7-қадам. Деректер бұлты <br>
            Деректер бұлтымен ары қарай не істеу керек? <br>
            </p>
            <p>Толығырақ: <a href="https://www.profguide.io/article/7_shagov_proidya_kotorie_vi_smojete_vibrat_sebe_professiu.html" target="_blank">П-Ориент</a></p>
        </div>
      </div>
    <img class="img_1" src="./ImagesZhan/Prof_img.png">
    </div>

    <div class="logo_photos">
        <img class="UTO" , src="https://dostyq.online/_nuxt/e2502090395d7afe8abdfcb01c713ea0.svg">
        <img class="CTO" , src="https://dostyq.online/_nuxt/941bcd305675a24d0808f22efbc91e9a.svg">
        <img class="EDU" , src="https://dostyq.online/_nuxt/81d6c6288accfda8214e4d06cdfb2f8c.svg">
        <img class="BIL" , src="https://dostyq.online/_nuxt/157583fe453e52b4d55f673fd59a803e.svg">
        <img class="SDU" , src="https://dostyq.online/_nuxt/5249f9c4d7e1b90c8044d114b748b830.svg">
        <img class="IQANAT" , src="https://dostyq.online/_nuxt/dabfe5acb2e2df9320f434389052c5ef.svg">
    </div>

    <div class="Div2_Polnye">
    <div class="Div2">
        <div class="Stroka1">
            <h3>Болашаққа дайындықты мамандық<br>таңдаудан бастаңыз</h3>
            <h5>Өйткені, сізде 5 өмір жоқ</h5>
        </div>
        <div class="Stroka2">
            <h6>&#10003; Кәсіби бейімділіктердің анықтамасы</h6>
            <h6>&#10003; Сәйкес мамандықтарды таңдау</h6>
            <h6>&#10003; Таңдамалы пәндер тізімі</h6>
            <h6>&#10003; Бар болғаны 20 минутты алады</h6>
        </div>
        <a href="https://proforientator.ru/tests/" target="_blank"> <button>Сынақты бастау</button></a>
    </div>
    <img src="./ImagesZhan/Phones.png">
</div>

<div class="stroka1">
    <div class="str1">
      <img src="./ImagesZhan/Logo_Dostyq.png">
      <h5>Бізбен байланысыңыз</h5>
      <h5>+7 707 422 19 19</h5>
    </div>
    <div class="str2">
      <h5>біз әлеуметтік желілердеміз<img src="https://dostyq.online/_nuxt/3b14889642828170e4c2d5ed4c46054f.svg"> <img src="https://dostyq.online/_nuxt/e6dbe3812e3c422a9e3779d20d87e0d4.svg"> <img src="https://dostyq.online/_nuxt/61d7c7fca1769621de95c32b53e3efea.svg"></h5>
    </div>
    </div>
    <div class="stroka2">
      <div class="str3">
       <h5>© 2022 Dostyq Bilim. Барлық құқықтар сақталған.</h5>
      </div>
      <div class="str4">
      <h5>Құпиялылық саясаты. </h5>
      <h5>Келісімшарт бойынша ұсыныс.</h5>
      </div>
    </div>
    <script src="Main.js?v=<?php echo time(); ?>"></script>
</body>
</html>
